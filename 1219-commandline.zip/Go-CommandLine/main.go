package main

import (
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"

	jsoniter "github.com/json-iterator/go"
)

var b *BPMClient
var id string

func main() {
	//登入-業務人員
	id = login("ruby.Fan")

	//建立使用者(建立Test人員)
	uId, _ := b.AddUser("test人員1218", true)

	//使用者套用權限(套用營運業務部主管)
	b.AddMembership("{\"user_id\":\"" + fmt.Sprintf("%v", uId) + "\",\"group_id\":\"26\",\"role_id\":\"2\"}")

	//啟單:部品零件贈送申請單 成功回傳cId
	fmt.Println("輸入ProcessID:")
	fmt.Println("6692105922161776422")

	//money:金額 //int
	//attm:經辦  //int
	//金額小於5000會直接到經辦-hoom
	process := b.CreateProcessCase("6692105922161776422", "{\"modelInput\":{\"money\":6000, \"attm\":52}}")

	fmt.Println("部品零件贈送申請單-啟單成功!")

	//存取caseId
	cId := GetFieldFromJson([]string{"caseId"}, process)
	fmt.Println("caseId:" + cId)

	//登出換-業務主管審核
	b.GetLogoutService()
	login("choc")
	sign(cId)

	//登出換-副總審核
	b.GetLogoutService()
	login("test人員1218")
	sign(cId)

	//登出換-總經理審核
	b.GetLogoutService()
	login("james")
	sign(cId)

	//登出換-經辦審核
	b.GetLogoutService()
	login("xiaopeng_fu")
	sign(cId)

	if string(b.GetCaseArchivedTaskDetail(cId)) != "[]" {
		fmt.Println("部品零件贈送申請單-已完成")
	}

	b.DeleteUser(fmt.Sprintf("%v", uId))
	print("已刪除test人員1218")

	fmt.Scan(&id)
}

// 審核任務 簽核狀態都預設ture
func sign(caseId string) {

	//取得taskID
	tasks := b.GetCasePendingTaskDetail(caseId)
	if string(tasks) == "[]" {
		fmt.Println("結束")
	} else {

		//處理取出第一筆資料的taskId //因為單線流程只會同時存在一個任務
		tId := RebuildJsonTest(tasks, []string{"name", "id"})
		fmt.Println("~~~審核中~~~", tId)
		taskId := string(tId[0][1])

		//審核內容 "status":審核狀態 //boolean
		status := content("status", "true")
		t := b.ExecuteTask(taskId, status)
		if t == 204 {
			fmt.Println("審核結果通過!")
		} else {
			fmt.Println("失敗")
		}
	}
}

func login(user string) string {
	b = New(user)
	fmt.Println("已登入:" + user)
	return b.GetUserId()
}

func content(key string, value string) string {
	m := make(map[string]string)
	m[key] = value

	c, err := json.Marshal(m)
	if err != nil {
		fmt.Println("json.Marshal failed:", err)
	}
	return string(c)
}

func (b *BPMClient) GetUserId() string {

	uri := b.apiUri + "system/session/unusedId"

	//log.Println("GetUserId() -uri", uri)
	resp, err := b.request.Get(uri)
	if err != nil {
		log.Fatal(err)
	}
	//log.Printf("GetUserId() - b.request:\n %+v", b.request)
	log.Println("GetUserId() - Status Code:", resp.StatusCode())

	s2 := Rebuild(string(resp.Body()), "user_id")

	return s2

}

func Rebuild(jsonBody string, key ...string) string {
	var s1 map[string]string

	err := json.Unmarshal([]byte(jsonBody), &s1)
	if err != nil {
		log.Println("反序列化失敗", err)
		os.Exit(3)
	}
	s2 := make(map[string]string)
	for _, keyy := range key {
		s2[keyy] = s1[keyy]
	}

	value := s2["caseId"]
	return value
}

func GetFieldFromJson(path []string, value []byte) string {
	var temp jsoniter.Any
	for i, v := range path {
		if i == 0 {
			temp = jsoniter.Get(value, v)
			if temp == nil {
				return ""
			}
		} else {
			temp = temp.Get(v)
			if temp == nil {
				return ""
			}
		}
	}

	switch temp.ValueType() {
	case jsoniter.InvalidValue, jsoniter.NilValue, jsoniter.BoolValue, jsoniter.ArrayValue, jsoniter.ObjectValue:
		return ""
	case jsoniter.StringValue:
		return temp.ToString()
	case jsoniter.NumberValue:
		return strconv.Itoa(temp.ToInt())
	}
	return ""
}
